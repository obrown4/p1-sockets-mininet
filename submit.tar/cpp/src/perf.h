#pragma once
struct Perf {
  int kbytes;  // in Kb
  double rate; // in Mbps
  int rtt;     // in ms
};